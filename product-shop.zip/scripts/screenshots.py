"""Capture README screenshots (needs: pip install playwright && playwright install chromium; server running on :8000)."""
from playwright.sync_api import sync_playwright

BASE = "http://localhost:8000"
OUT = "docs/screenshots"
with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={"width": 1280, "height": 900})
    pg.goto(BASE + "/#/"); pg.wait_for_selector(".card")
    pg.screenshot(path=f"{OUT}/listing.png")
    pg.goto(BASE + "/#/?q=lamp"); pg.wait_for_selector(".card")
    pg.screenshot(path=f"{OUT}/search.png")
    pg.goto(BASE + "/#/product/8"); pg.wait_for_selector(".detail")
    pg.screenshot(path=f"{OUT}/details.png")
    # Part 2: admin dashboard
    pg.goto(BASE + "/admin/"); pg.wait_for_selector("#simulate")
    pg.click("#simulate"); pg.wait_for_selector(".dist-row"); pg.wait_for_timeout(300)
    pg.screenshot(path=f"{OUT}/admin-analytics.png", full_page=True)
    pg.click("#tab-theme"); pg.wait_for_timeout(600)
    pg.select_option("#preset", "midnight"); pg.wait_for_timeout(700)
    pg.screenshot(path=f"{OUT}/admin-theme.png", full_page=True)
    b.close()
