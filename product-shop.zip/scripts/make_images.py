"""Generate simple self-contained SVG product illustrations into frontend/images/.
Run once (output is committed), so the app works fully offline."""
import re
from pathlib import Path

OUT = Path(__file__).resolve().parent.parent / "frontend" / "images"
OUT.mkdir(parents=True, exist_ok=True)

# slug: (background, shape colour, accent, drawing)
ITEMS = {
 "walnut-desk-tray": ("#E9E4DC", "#5B3A29", "#8A5A3C", '<rect x="80" y="130" width="240" height="110" rx="10" fill="{a}"/><rect x="92" y="142" width="70" height="86" rx="5" fill="{b}"/><rect x="170" y="142" width="70" height="86" rx="5" fill="{b}"/><rect x="248" y="142" width="60" height="86" rx="5" fill="{b}"/>'),
 "linen-notebook-set": ("#E4E8EE", "#C9B79C", "#2B4162", '<rect x="100" y="70" width="110" height="160" rx="6" fill="{b}"/><rect x="190" y="90" width="110" height="160" rx="6" fill="{a}"/><rect x="190" y="90" width="12" height="160" fill="#00000022"/><rect x="100" y="70" width="12" height="160" fill="#00000022"/>'),
 "brass-pen-stand": ("#E8E6DF", "#B8892E", "#6E5115", '<path d="M140 150h120l-10 90h-100z" fill="{a}"/><rect x="160" y="70" width="8" height="90" fill="#2B4162" transform="rotate(-8 164 150)"/><rect x="190" y="60" width="8" height="100" fill="#C0392B" transform="rotate(2 194 150)"/><rect x="220" y="75" width="8" height="85" fill="#1E6B52" transform="rotate(10 224 150)"/>'),
 "ceramic-pour-over-set": ("#E3E9E6", "#F2F0EA", "#7C9A8E", '<path d="M130 70h140l-30 60h-80z" fill="{a}" stroke="{b}" stroke-width="4"/><rect x="150" y="130" width="100" height="14" fill="{b}"/><path d="M145 150h110l8 90h-126z" fill="{a}" stroke="{b}" stroke-width="4"/><rect x="150" y="190" width="100" height="40" fill="{b}" opacity=".5"/>'),
 "olive-wood-board": ("#ECE8E0", "#A9793E", "#7A5224", '<rect x="90" y="110" width="200" height="120" rx="40" fill="{a}"/><rect x="290" y="150" width="40" height="26" rx="13" fill="{a}"/><circle cx="318" cy="163" r="6" fill="#ECE8E0"/><path d="M110 150q60-20 120 0M110 180q70 20 140 0" stroke="{b}" stroke-width="3" fill="none"/>'),
 "stoneware-mug-pair": ("#E9E6E1", "#D9D3C7", "#4C6A6B", '<rect x="90" y="120" width="90" height="100" rx="10" fill="{a}"/><path d="M180 140q35 0 35 30t-35 30" stroke="{a}" stroke-width="12" fill="none"/><rect x="215" y="150" width="90" height="90" rx="10" fill="{b}"/><circle cx="130" cy="150" r="3" fill="{b}"/><circle cx="150" cy="190" r="3" fill="{b}"/><circle cx="260" cy="180" r="3" fill="{a}"/>'),
 "enamel-kettle": ("#E6E9EE", "#2B4A8B", "#F2F0EA", '<path d="M110 240h160l15-100q0-30-30-30h-130q-30 0-30 30z" fill="{a}"/><path d="M285 150q50-30 55-80" stroke="{a}" stroke-width="14" fill="none"/><path d="M130 110q70-70 140 0" stroke="#1C1C1C" stroke-width="10" fill="none"/><circle cx="200" cy="100" r="9" fill="#1C1C1C"/>'),
 "arc-desk-lamp": ("#E4E6EC", "#1F2A44", "#F2B134", '<rect x="100" y="228" width="110" height="14" rx="6" fill="{a}"/><path d="M155 228V120q0-60 90-60" stroke="{a}" stroke-width="10" fill="none"/><path d="M225 60l60 20-14 36z" fill="{a}"/><path d="M255 116l8 40M235 120l-6 40M275 108l24 36" stroke="{b}" stroke-width="5" stroke-linecap="round"/>'),
 "paper-globe-pendant": ("#E8E7E3", "#F6F1E4", "#B9AE95", '<line x1="200" y1="0" x2="200" y2="85" stroke="#333" stroke-width="3"/><circle cx="200" cy="160" r="75" fill="{a}" stroke="{b}" stroke-width="3"/><ellipse cx="200" cy="160" rx="30" ry="75" fill="none" stroke="{b}" stroke-width="2"/><ellipse cx="200" cy="160" rx="62" ry="75" fill="none" stroke="{b}" stroke-width="2"/><line x1="125" y1="160" x2="275" y2="160" stroke="{b}" stroke-width="2"/>'),
 "rechargeable-lantern": ("#E2E7E5", "#1E6B52", "#F6D77A", '<path d="M170 80q30-40 60 0" stroke="#333" stroke-width="8" fill="none"/><rect x="150" y="80" width="100" height="16" rx="6" fill="{a}"/><rect x="158" y="96" width="84" height="110" rx="10" fill="{b}" opacity=".85"/><rect x="150" y="206" width="100" height="22" rx="6" fill="{a}"/>'),
 "canvas-daypack": ("#E8E4DB", "#7A7C4B", "#5A3A26", '<rect x="120" y="70" width="160" height="170" rx="40" fill="{a}"/><rect x="140" y="150" width="120" height="70" rx="12" fill="#00000018"/><rect x="170" y="165" width="60" height="10" rx="5" fill="{b}"/><path d="M150 70q50-45 100 0" stroke="{b}" stroke-width="10" fill="none"/>'),
 "leather-card-wallet": ("#E7E3DE", "#8B4A2B", "#C98B5C", '<rect x="100" y="100" width="200" height="130" rx="14" fill="{a}"/><path d="M100 140h200" stroke="#00000030" stroke-width="3"/><rect x="100" y="140" width="200" height="90" rx="14" fill="{b}"/><circle cx="265" cy="185" r="6" fill="{a}"/>'),
}

for slug, (bg, a, b, art) in ITEMS.items():
    art = art.replace("{a}", a).replace("{b}", b)
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300" role="img" aria-label="{slug.replace("-", " ")}">'
           f'<rect width="400" height="300" fill="{bg}"/>{art}</svg>')
    (OUT / f"{slug}.svg").write_text(svg)
print(f"Wrote {len(ITEMS)} images to {OUT}")
